
/**
 * Create a ISAJson URI from a ISATab string entry
 * 
 * This is a placeholder function. It has currently no function, but as soon as it is implemented it will already be placed at all relevant code locations.
 */
export function URIModule_fromString(s) {
    return s;
}

/**
 * Create a ISATab string entry from a ISAJson URI
 * 
 * This is a placeholder function. It has currently no function, but as soon as it is implemented it will already be placed at all relevant code locations.
 */
export function URIModule_toString(s) {
    return s;
}

