# fable-library

Core library used by F# projects compiled with [Fable](https://fable.io).