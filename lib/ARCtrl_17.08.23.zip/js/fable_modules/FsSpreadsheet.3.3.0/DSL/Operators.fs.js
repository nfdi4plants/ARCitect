import { RequiredSource$1_$ctor_2B595, OptionalSource$1_$ctor_2B595 } from "./Expression.fs.js";

export const optional = OptionalSource$1_$ctor_2B595(void 0);

export const required = RequiredSource$1_$ctor_2B595(void 0);

